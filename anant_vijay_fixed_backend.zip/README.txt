ANANT VIJAY AUDITORIUM — DYNAMIC WEEKLY MOVIE VOTING

WHAT THIS VERSION FIXES
- User website is separate from Super Admin frontend.
- Movies are stored server-side in Netlify Blobs, not browser localStorage.
- Super Admin can change the movie list every week from /admin.html.
- Super Admin can open/close voting and reset votes.
- User votes are stored centrally, so votes from different devices reach the same backend.
- Your latest Anant Vijay Auditorium photo is included as auditorium.jpg.
- No weekly Netlify redeployment is required just to change movies.

IMPORTANT DEPLOYMENT SETUP
1. Create a new Netlify site from this project (or upload the folder/repository).
2. Netlify will deploy:
   public/ = website
   netlify/functions/ = backend API
3. In Netlify Site configuration > Environment variables, set:
   ADMIN_PASSWORD = your strong admin password
   ADMIN_SECRET = a long random secret string
4. Redeploy once after setting variables.
5. User URL: /
6. Super Admin URL: /admin.html

DEMO DEFAULTS
If you do not set environment variables, the demo password is admin123 and the JWT secret is a placeholder.
DO NOT use these defaults for a real deployment.

WEEKLY PROCESS
Super Admin -> Admin page -> edit/add/remove movies -> Save Weekly Movies.
The public website automatically reads the updated list from the backend.

LIMITATION / NEXT PRODUCTION STEPS
This is a real server-side demo architecture, but for a public production voting system you should add:
- stronger identity/rate limiting (one person/eligible user = one vote)
- audit logs
- proper role-based accounts if adding Admin/Vendor/Scanner
- image upload storage
- HTTPS/custom domain (Netlify provides HTTPS)
- backup/report export

The four-role theatre system you described can be added on top of this backend:
Super Admin, Admin, Vendor, Scanner.
