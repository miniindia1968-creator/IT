
const { getStore } = require("@netlify/blobs");
const jwt = require("jsonwebtoken");

const SECRET = process.env.ADMIN_SECRET || "CHANGE_THIS_SECRET";
const store = getStore({ name: "anant-vijay-voting", consistency: "strong" });

const DEFAULT_MOVIES = [
  {id:"m1", name:"Pushpa 2", language:"Hindi", genre:"Action / Drama", description:"A powerful action drama.", poster:""},
  {id:"m2", name:"Bahubali 3", language:"Hindi", genre:"Action / Adventure", description:"An epic adventure.", poster:""},
  {id:"m3", name:"Vikram", language:"Hindi", genre:"Action / Thriller", description:"A high-intensity thriller.", poster:""},
  {id:"m4", name:"Interstellar", language:"English", genre:"Sci-Fi / Drama", description:"A journey beyond space and time.", poster:""},
  {id:"m5", name:"Inception", language:"English", genre:"Sci-Fi / Thriller", description:"A mind-bending experience.", poster:""},
  {id:"m6", name:"Avatar", language:"English", genre:"Adventure / Sci-Fi", description:"An immersive adventure.", poster:""}
];

async function getData(){
  let data = await store.get("data", {type:"json"});
  if(!data){
    data = {movies: DEFAULT_MOVIES, votes:{}, votingOpen:true, weekLabel:"Next Week"};
    await store.setJSON("data", data);
  }
  return data;
}
async function saveData(data){ await store.setJSON("data", data); }

function json(body, status=200){
  return {statusCode:status, headers:{"Content-Type":"application/json","Access-Control-Allow-Origin":"*"}, body:JSON.stringify(body)};
}
function auth(event){
  const h = event.headers.authorization || "";
  if(!h.startsWith("Bearer ")) return false;
  try { jwt.verify(h.slice(7), SECRET); return true; } catch(e){ return false; }
}
function adminToken(){
  return jwt.sign({role:"superadmin"}, SECRET, {expiresIn:"12h"});
}

exports.handler = async (event) => {
  try{
    const method = event.httpMethod;
    const path = (event.path || "").split("/").filter(Boolean).pop() || "";
    if(method === "OPTIONS") return json({ok:true});
    const data = await getData();

    if(method === "GET" && path === "movies"){
      const results = data.movies.map(m=>({...m, votes:data.votes[m.id]||0}));
      return json({movies:results, votingOpen:data.votingOpen, weekLabel:data.weekLabel});
    }

    if(method === "POST" && path === "vote"){
      if(!data.votingOpen) return json({error:"Voting is closed."}, 403);
      const body = JSON.parse(event.body || "{}");
      if(!body.movieId || !data.movies.some(m=>m.id===body.movieId))
        return json({error:"Invalid movie."},400);
      // One-vote-per-browser is enforced in the frontend; production-grade
      // identity/rate limiting can be added later if required.
      data.votes[body.movieId] = (data.votes[body.movieId]||0) + 1;
      await saveData(data);
      return json({ok:true, votes:data.votes[body.movieId]});
    }

    if(method === "POST" && path === "login"){
      const body = JSON.parse(event.body || "{}");
      const password = process.env.ADMIN_PASSWORD || "admin123";
      if(body.password !== password) return json({error:"Invalid password"},401);
      return json({token:adminToken()});
    }

    if(!auth(event)) return json({error:"Unauthorized"},401);

    if(method === "GET" && path === "admin-data"){
      return json(data);
    }

    if(method === "PUT" && path === "movies"){
      const body = JSON.parse(event.body || "{}");
      if(!Array.isArray(body.movies)) return json({error:"movies must be an array"},400);
      data.movies = body.movies.map((m,i)=>({
        id:m.id || `m${Date.now()}${i}`,
        name:String(m.name||"Untitled"),
        language:m.language==="English"?"English":"Hindi",
        genre:String(m.genre||""),
        description:String(m.description||""),
        poster:String(m.poster||"")
      }));
      if(body.weekLabel !== undefined) data.weekLabel=String(body.weekLabel);
      await saveData(data);
      return json({ok:true, data});
    }

    if(method === "PUT" && path === "voting"){
      const body = JSON.parse(event.body || "{}");
      data.votingOpen = !!body.open;
      await saveData(data);
      return json({ok:true, votingOpen:data.votingOpen});
    }

    if(method === "POST" && path === "reset"){
      data.votes = {};
      await saveData(data);
      return json({ok:true});
    }

    return json({error:"Not found"},404);
  }catch(e){
    console.error(e);
    return json({error:"Server error"},500);
  }
};
